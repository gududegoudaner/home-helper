#include "sys.h"                  

void Servo_Init(void)							//��ʼ��
{
	PWM_Init();
}

void Servo_SetAngle(float Angle)				//���ö���Ƕ�
{
	PWM_SetCompare4(Angle/180*2000+500);
	
}
void Servo_1(void)								//���0��,�ص�
{
	Servo_SetAngle(0.0);
}
void Servo_0(void)								//���90�ȣ�����λ
{
	Servo_SetAngle(90.0);
}
void Servo_2(void)								//���180�ȣ�����
{
	Servo_SetAngle(180.0);
}
void Servo_Sta(void)							//�ϴ����״̬
{

	char temp[400]; 
	
	if(strstr((char *)mqtt_CMDOutPtr+2,"\"params\":{\"Sg90state\":0}"))
	{
		sprintf(temp,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"Sg90state\":0},\"version\":\"1.0.0\"}"); 	
	}
	else if(strstr((char *)mqtt_CMDOutPtr+2,"\"params\":{\"Sg90state\":1}"))            
		sprintf(temp,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"Sg90state\":1},\"version\":\"1.0.0\"}"); 
	else if(strstr((char *)mqtt_CMDOutPtr+2,"\"params\":{\"Sg90state\":2}"))            
		sprintf(temp,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"Sg90state\":2},\"version\":\"1.0.0\"}");	
	mqtt_PublishQs0(PUBLISH_TOPIC1,temp,strlen(temp)); 
}

