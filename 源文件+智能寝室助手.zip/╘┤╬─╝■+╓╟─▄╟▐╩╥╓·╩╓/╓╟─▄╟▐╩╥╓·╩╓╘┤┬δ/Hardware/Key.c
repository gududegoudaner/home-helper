#include "sys.h"

u8 Key_M_flag=1;									//�˵���־λ
u8 Key_I_flag=1;									//���ӱ�־λ
u8 change1_flag=0;									//�ı��־λ
u8 change2_flag=0;
	
void Key_Init(void)									//��ʼ����PB0,PB1
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	
}

uint8_t Key_GetNum(void)							//�ж��Ǹ���������
{
	uint8_t KeyNum=0;
	uint8_t KeyNum2=0;
	
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==0)
	{
		delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==0);
		delay_ms(20);
		KeyNum=1;
		OLED_ShowNum(3,11,1,1);
		return KeyNum;
	}
	
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==0)
	{
		delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==0);
		delay_ms(20);
		KeyNum2=2;
		return KeyNum2;
	}	
	else 
	return 0;
		
	
}
void Key_menu(void)									//�л��˵�����
{
		if(Key_GetNum()==1)
		{	
			OLED_ShowNum(3,12,2,1);
			OLED_Clear();
			
			if(Key_M_flag==1)
			{				
				Key_M_flag=2;			
			}
			else if(Key_M_flag==2)
			{
				Key_M_flag=1;	
			}	
			
		}
}

void Key_intelligent(void)							//�л�����ģʽ����
{
	if( Key_GetNum()==2 )
	{
		if(Key_I_flag==2)
			Key_I_flag=1;		
		else Key_I_flag=2;	
		change1_flag=1;
	}
}
