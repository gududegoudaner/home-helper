#ifndef __LED_H__
#define __LED_H__

#include "sys.h"

#define LED1_GPIO_PIN   GPIO_Pin_4
//#define LED2_GPIO_PIN   GPIO_Pin_8
#define LED_GPIO_PORT   GPIOA
#define LED_GPIO_CLK    RCC_APB2Periph_GPIOA

#define LED1_ON       GPIO_ResetBits(LED_GPIO_PORT, LED1_GPIO_PIN)         
#define LED1_OFF      GPIO_SetBits(LED_GPIO_PORT, LED1_GPIO_PIN)           

//#define LED2_ON       GPIO_ResetBits(LED2_GPIO_PORT, LED_GPIO_PIN)         
//#define LED2_OFF      GPIO_SetBits(LED2_GPIO_PORT, LED_GPIO_PIN)           

void LED_AllOn(void);	
void LED_AllOff(void);
//void LED1_On(void);
//void LED1_Off(void);
//void LED2_On(void);
//void LED2_Off(void);
void LED_Sta(void);

void LED_GPIO_Config(void);


#endif

