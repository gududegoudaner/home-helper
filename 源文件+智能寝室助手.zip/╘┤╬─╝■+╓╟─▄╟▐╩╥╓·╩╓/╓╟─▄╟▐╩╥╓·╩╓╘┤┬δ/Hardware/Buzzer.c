#include "sys.h"                  
void Buzzer_Init(void)								//��������ʼ����PA0
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	
	GPIO_SetBits(GPIOA,GPIO_Pin_0);
	
}
void Buzzer_ON(void)								//�򿪷�����
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	
}
void Buzzer_OFF(void)								//�رշ�����
{
	GPIO_SetBits(GPIOA,GPIO_Pin_0);
}
void Buzzer_Turn(void)								//������״̬�ı�
{
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_0)==0)
	{
	GPIO_SetBits(GPIOA,GPIO_Pin_0);
	}
	else
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_0);
	}
}
void Buzzer_Sta(void)								//�ϴ�����������
{

	char temp[400]; 
	if(strstr((char *)mqtt_CMDOutPtr+2,"\"params\":{\"Buzzer\":1}"))
	{		
		sprintf(temp,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"Buzzer\":1},\"version\":\"1.0.0\"}"); 	
		u1_printf("temp:%s\r\n",temp);
	}
	else if(strstr((char *)mqtt_CMDOutPtr+2,"\"params\":{\"Buzzer\":0}"))            
	{
		sprintf(temp,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"Buzzer\":0},\"version\":\"1.0.0\"}");
		u1_printf("temp:%s\r\n",temp);	
	}
	mqtt_PublishQs0(PUBLISH_TOPIC1,temp,strlen(temp)); 
}

