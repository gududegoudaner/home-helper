#ifndef __Menu_H
#define __Menu_H

#include "sys.h"

void menu1(void);	
void menu2(void);

#endif

