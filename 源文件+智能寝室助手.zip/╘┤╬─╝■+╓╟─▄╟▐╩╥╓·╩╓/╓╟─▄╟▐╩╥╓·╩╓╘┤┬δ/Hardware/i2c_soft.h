#ifndef __I2C_SOFT_H__
#define __I2C_SOFT_H__

#include "sys.h"

// IIC SCL��������
#define IIC_SCL_CLOCK   RCC_APB2Periph_GPIOB     // ʱ��
#define IIC_SCL_PORT    GPIOB                    // �˿�
#define IIC_SCL_PIN     GPIO_Pin_10               // ���ź�

// IIC SCL��ƽ����
#define SET_IIC_SCL(s)  s > 0 ? GPIO_SetBits(IIC_SCL_PORT, IIC_SCL_PIN) : GPIO_ResetBits(IIC_SCL_PORT, IIC_SCL_PIN)


// IIC SDA��������
#define IIC_SDA_CLOCK   RCC_APB2Periph_GPIOB     // ʱ��
#define IIC_SDA_PORT    GPIOB                    // �˿�
#define IIC_SDA_PIN     GPIO_Pin_11               // ���ź�

// IIC SDA��ƽ����
#define SET_IIC_SDA(s)  s > 0 ? GPIO_SetBits(IIC_SDA_PORT, IIC_SDA_PIN) : GPIO_ResetBits(IIC_SDA_PORT, IIC_SDA_PIN)  
#define READ_IIC_SDA    GPIO_ReadInputDataBit(IIC_SDA_PORT, IIC_SDA_PIN)

void iic_init(void);
uint8_t iic_write_bytes(uint8_t addr, uint8_t *buf, uint8_t buf_size);
uint8_t iic_receive_bytes(uint8_t addr, uint8_t *buf, uint8_t buf_size);

#endif
