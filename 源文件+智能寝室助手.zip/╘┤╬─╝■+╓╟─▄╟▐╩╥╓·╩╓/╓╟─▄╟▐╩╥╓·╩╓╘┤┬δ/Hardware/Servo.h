#ifndef __Servo_H
#define __Servo_H

#include "sys.h"

void Servo_Init(void);
void Servo_SetAngle(float Angle);

void Servo_0(void);
void Servo_1(void);
void Servo_2(void);

void Servo_Sta(void);

#endif

