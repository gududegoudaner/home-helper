#include "sys.h"

void LED_AllOff(void);
void LED_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(LED_GPIO_CLK, ENABLE);
	GPIO_InitStruct.GPIO_Pin = LED1_GPIO_PIN;//| LED2_GPIO_PIN
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(LED_GPIO_PORT, &GPIO_InitStruct);	
	LED_AllOff();
}

void LED_AllOn(void)
{
	LED1_ON;
	//LED2_ON;
}

void LED_AllOff(void)
{
	LED1_OFF;
	//LED2_OFF;
}

//void LED2_On(void)
//{
//	LED2_ON;
//}

//void LED2_Off(void)
//{
//	LED2_OFF;	
//}

void LED_Sta(void)
{

	char temp[400]; 
	if(strstr((char *)mqtt_CMDOutPtr+2,"\"params\":{\"LightSwitch\":1}"))
	{
		sprintf(temp,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"LightSwitch\":1},\"version\":\"1.0.0\"}"); 	
	}
	else if(strstr((char *)mqtt_CMDOutPtr+2,"\"params\":{\"LightSwitch\":0}"))            
		sprintf(temp,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"LightSwitch\":0},\"version\":\"1.0.0\"}");  
	mqtt_PublishQs0(PUBLISH_TOPIC1,temp,strlen(temp)); 
}


