#include "sys.h"   

u8 temper0; 
u8 temper1;	
u8 humi0;
u8 humi1;

unsigned int rec_data[4];

void DHT11_GPIO_Init_OUT(void)								//对于stm32来说，是输出，PA8
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP; 		//推挽输出
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);

}

void DHT11_GPIO_Init_IN(void)								//对于stm32来说，是输入
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING; //浮空输入
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);

}




void DHT11_Start(void)										//主机发送开始信号
{
	DHT11_GPIO_Init_OUT(); 									//输出模式
	
	dht11_high; 											//先拉高
	delay_us(30);
	
	dht11_low; 												//拉低电平至少18us
	delay_ms(20);
	
	dht11_high; 											//拉高电平20~40us
	delay_us(30);
	
	DHT11_GPIO_Init_IN(); 									//输入模式
}

char DHT11_Rec_Byte(void)									//获取一个字节
{
	unsigned char i = 0;
	unsigned char data;
	
	for(i=0;i<8;i++) 										//1个数据就是1个字节byte，1个字节byte有8位bit
	{
		while( Read_Data == 0); 							//从1bit开始，低电平变高电平，等待低电平结束
		delay_us(30); 										//延迟30us是为了区别数据0和数据1，0只有26~28us
		
		data <<= 1; 										//左移
		
		if( Read_Data == 1 ) 								//如果过了30us还是高电平的话就是数据1
		{
			data |= 1; 										//数据+1
		}
		
		while( Read_Data == 1 ); 							//高电平变低电平，等待高电平结束
	}
	
	return data;
}

u8 DHT11_REC_Data(u8 *TempH,u8 *TempL,u8 *HumiH,u8 *HumiL)	//获取数据
{
	unsigned int R_H,R_L,T_H,T_L;
	unsigned char CHECK;
	
	DHT11_Start(); 											//主机发送信号
	dht11_high; 											//拉高电平
	
	if( Read_Data == 0 ) 									//判断DHT11是否响应
	{
		while( Read_Data == 0); 							//低电平变高电平，等待低电平结束
		while( Read_Data == 1); 							//高电平变低电平，等待高电平结束
		
		R_H = DHT11_Rec_Byte();
		R_L = DHT11_Rec_Byte();
		T_H = DHT11_Rec_Byte();
		T_L = DHT11_Rec_Byte();
		CHECK = DHT11_Rec_Byte(); 							//接收5个数据
		
		dht11_low; 											//当最后一bit数据传送完毕后，DHT11拉低总线 50us
		delay_us(55); 										//这里延时55us
		dht11_high; 										//随后总线由上拉电阻拉高进入空闲状态。
		
		if(R_H + R_L + T_H + T_L == CHECK) 					//和检验位对比，判断校验接收到的数据是否正确
		{
			*HumiH = R_H;
			*HumiL = R_L;
			*TempH = T_H;
			*TempL = T_L;
			
			
			return 1;
		}
		else
		{
			u1_printf("校验失败\r\n");
			return 0;
		}
	}

	return 1;
}
void Sensor_DHT11(void)										//上传DHT11	
{
	u8 temp;
	
	char temp01[256];
	
	temp=DHT11_REC_Data(&temper0,&temper1,&humi0,&humi1);
	if(temp)
	{
		u1_printf("temperature is %d.%d\r\n",temper0,temper1);
		u1_printf("humidity is %d.%d\r\n",humi0,humi1);
		
		sprintf(temp01,"{\"method\":\"thing.event.property.post\",\"id\":\"203302322\",\"params\":{\"CurrentHumidity\":%d.%d,\"CurrentTemperature\":%d.%d},\"version\":\"1.0.0\"}",humi0,humi1,temper0,temper1);  //构建回复湿度温度数据
		mqtt_PublishQs0(PUBLISH_TOPIC1,temp01,strlen(temp01));
		
	}
	else
	{
		u1_printf("DHT11传感器读取失败\r\n");	
	}
}


