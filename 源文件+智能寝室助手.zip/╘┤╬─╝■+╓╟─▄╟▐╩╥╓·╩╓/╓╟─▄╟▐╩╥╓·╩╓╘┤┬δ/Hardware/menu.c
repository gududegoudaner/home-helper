#include "sys.h"

void menu1(void)										//��һҳ
{	
	OLED_ShowString(1,1,"Date:");						//����
	OLED_ShowNum(1,6,MyRTC_Time[0],4);
	OLED_ShowString(1,10,"\\");
	OLED_ShowNum(1,11,MyRTC_Time[1],2);
	OLED_ShowString(1,13,"\\");
	OLED_ShowNum(1,14,MyRTC_Time[2],2);
	
	OLED_ShowString(2,1,"Time:");						//ʱ��
	OLED_ShowNum(2,6,MyRTC_Time[3],2);
	OLED_ShowString(2,8,":");
	OLED_ShowNum(2,9,MyRTC_Time[4],2);
	OLED_ShowString(2,11,":");
	OLED_ShowNum(2,12,MyRTC_Time[5],2);	
	
	OLED_ShowString(3,1,"Day:");						//�ܼ�
	OLED_ShowNum(3,6,MyRTC_Time[6],2);
	
	OLED_ShowString(4,1,"INT:");						//����ģʽ�Ƿ���
	if(Key_I_flag==2)
	OLED_ShowString(4,5,"on ");
	else if(Key_I_flag==1)
	OLED_ShowString(4,5,"off");
	
	OLED_ShowString(4,10,"Menu1");
	
}
void menu2(void)										//�ڶ�ҳ
{
	OLED_ShowString(1,1,"Temp:");						//�¶�
	OLED_ShowNum(1,7,temper0,2);
	OLED_ShowString(1,9,".");
	OLED_ShowNum(1,10,temper1,1);
	
	OLED_ShowString(2,1,"Humi:");						//ʪ��
	OLED_ShowNum(2,7,humi0,2);
	OLED_ShowString(2,9,".");
	OLED_ShowNum(2,10,humi1,1);
	
	OLED_ShowString(3,1,"Light:");						//����ǿ��
	OLED_ShowNum(3,7,current_light,2);
	OLED_ShowString(3,9,".");
	OLED_ShowNum(3,10,current_light,1);
	
	OLED_ShowString(4,10,"Menu2");
	
}
