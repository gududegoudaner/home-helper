#ifndef __Key_H
#define __Key_H

#include "sys.h"

void Key_Init(void);
uint8_t Key_GetNum(void);
void Key_menu(void);
void Key_intelligent(void);

extern u8 Key_M_flag;
extern u8 Key_I_flag;
extern u8 change1_flag;
extern u8 change2_flag;

#endif
