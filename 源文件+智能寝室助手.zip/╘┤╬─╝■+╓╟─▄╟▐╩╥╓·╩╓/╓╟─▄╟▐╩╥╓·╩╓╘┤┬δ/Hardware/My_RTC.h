#ifndef __My_RTC_H
#define __My_RTC_H

#include "sys.h"

void MyRTC_Init(void);
void RTC_Publish(void);
void RTC_Turn(long long int rce_time,u16* year,u16* yday,u8* month,u8* week,u8* day,u8* hour,u8* minute,u8* second);


void MyRTC_SetTime(void);
void MyRTC_ReadTime(void);

extern uint16_t MyRTC_Time[7];
extern u8 RTC_flag;
extern int U_Time[10];
extern long long int Unix_Time;
extern u16 year;
extern u16 yday;
extern u8 month;
extern u8 day;
extern u8 week;
extern u8 hour;
extern u8 minute;
extern u8 second;


#endif

