#ifndef __DHT11_H
#define __DHT11_H
#include "sys.h"                  // Device header



#define dht11_high GPIO_SetBits(GPIOA, GPIO_Pin_8)
#define dht11_low GPIO_ResetBits(GPIOA, GPIO_Pin_8)
#define Read_Data GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8)

void DHT11_GPIO_Init_OUT(void);
void DHT11_GPIO_Init_IN(void);
void DHT11_Start(void);
unsigned char DHT11_REC_Byte(void);
u8 DHT11_REC_Data(u8 *TempH,u8 *TempL,u8 *HumiH,u8 *HumiL);
void Sensor_DHT11(void);

extern u8 temper0; 
extern u8 temper1;	
extern u8 humi0;
extern u8 humi1;

#endif

