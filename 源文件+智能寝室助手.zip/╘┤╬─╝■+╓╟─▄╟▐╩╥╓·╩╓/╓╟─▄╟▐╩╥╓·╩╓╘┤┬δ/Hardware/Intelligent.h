#ifndef __Intelligent_H
#define __Intelligent_H

#include "sys.h"
void Intelligent_ON(void);
void Intelligent_OFF(void);
void Intelligent_Sta(void);


#endif
