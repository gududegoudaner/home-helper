#ifndef __TIME3_H
#define __TIME3_H
#include "sys.h"

void TIM3_Init(u32 arr,u32 psc);


#endif
