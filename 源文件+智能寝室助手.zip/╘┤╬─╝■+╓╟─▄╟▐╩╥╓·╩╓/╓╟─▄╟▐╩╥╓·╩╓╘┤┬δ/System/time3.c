#include "sys.h"
 
void TIM3_Init(u32 arr,u32 psc)										//��ʼ��
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	
	TIM_TimeBaseStructure.TIM_Period = arr;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure);
	
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);		
	TIM_Cmd(TIM3, ENABLE);
}

void TIM3_IRQHandler(void)											//�ж�����
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)  
	{
		
		switch(Ping_flag)
		{               
			case 0:mqtt_Ping();break;			
			case 1:TIM3_Init(6000-1,36000-1);mqtt_Ping();break;	
			case 2:mqtt_Ping(); break;
			case 3:Connect_flag = 0;TIM_Cmd(TIM3,DISABLE);break;	//��������
			default:break;
		}
		Ping_flag++;
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update); 					
	}

}
