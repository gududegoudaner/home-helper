#ifndef __TIME4_H
#define __TIME4_H
#include "sys.h"

void TIM4_Init(u16 arr,u16 psc);

#endif
