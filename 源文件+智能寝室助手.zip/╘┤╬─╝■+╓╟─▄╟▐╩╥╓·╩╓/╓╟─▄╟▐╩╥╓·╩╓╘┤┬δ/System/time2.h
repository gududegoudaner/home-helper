#ifndef __TIME2_H
#define __TIME2_H
#include "sys.h"

void TIM2_Init(u32 arr,u32 psc);

#endif
