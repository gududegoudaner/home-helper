#include "sys.h"                     					     
u8 mqtt_buff[400];										//���һ��������Ϣ
u8 Connect_flag = 0;									//wifi���ӱ�־λ
u8 ConnectPack_flag=0; 									//connect���ͳɹ���־λ
u8 SubscribePack1_flag = 0;								//����1�ɹ���־λ
u8 SubscribePack2_flag = 0;								//����2�ɹ���־λ
u8 Ping_flag = 0;
unsigned char  mqtt_TxBuf[10][400];						//��������            
unsigned char *mqtt_TxInPtr; 							//ָ��Ƭ�����͸�����������
unsigned char *mqtt_TxOutPtr;							//ָ���������͸���ƽ̨������
unsigned char *mqtt_TxEndPtr;

unsigned char  mqtt_RxBuf[10][400];						//��������           
unsigned char *mqtt_RxInPtr;                            
unsigned char *mqtt_RxOutPtr;                           
unsigned char *mqtt_RxEndPtr;

unsigned char  mqtt_CMDBuf[10][400];					//����ָ������              
unsigned char *mqtt_CMDInPtr;                               
unsigned char *mqtt_CMDOutPtr;                              
unsigned char *mqtt_CMDEndPtr;
	
char clientid[128];                                   	//�ͻ���id       
int  clientid_size;                                           

char username[128];                                     //�û���     
int  username_size;											 

char passward[128];                                   	//����      
int  passward_size;
	
char ServerIP[128];                                    	//�����IP��ַ  
int  ServerPort;

void Mqtt_Subscribe(char *topic_name, int QoS);
void mqtt_DealTxData (unsigned char *data, int size);

void MQTT_Buff_Init(void)								//������ʼ��
{	
	mqtt_TxInPtr=mqtt_TxBuf[0];               
	mqtt_TxOutPtr=mqtt_TxInPtr;               
    mqtt_TxEndPtr=mqtt_TxBuf[6]; 
	
	mqtt_RxInPtr=mqtt_RxBuf[0];               
	mqtt_RxOutPtr=mqtt_RxInPtr;               
    mqtt_RxEndPtr=mqtt_RxBuf[6];
	
	mqtt_CMDInPtr=mqtt_CMDBuf[0];                     
	mqtt_CMDOutPtr=mqtt_CMDInPtr;                     
	mqtt_CMDEndPtr=mqtt_CMDBuf[6];
	
	Mqtt_ConnectMessege();	
	Mqtt_Subscribe(SUBSCRIBE_TOPIC1, 0);
	Mqtt_Subscribe(SUBSCRIBE_TOPIC2, 0);
		
}
void Mqtt_Subscribe(char *topic_name, int QoS)			//���ı��ģ�QOS�ȼ���0��
{	
	
	int payload_size;									//��Ч�غɳ���
	int remaining_size;									//ʣ�೤��
	int len;
	int all_size=1;
	int variable_size = 2;								//�ɱ䱨ͷ����
	payload_size = 2 + strlen(topic_name)+1;
	remaining_size = variable_size+payload_size;	
	mqtt_buff[0]=0x82;
	while( remaining_size > 0)
    {
        len= remaining_size%128;
		remaining_size = remaining_size/128;
         
         if(remaining_size > 0)
         {
              len =len|0x80;							//ת�����ƺ����λ��һ
         }
         mqtt_buff[all_size++]=len;
     }
	mqtt_buff[all_size+0]=0x00;    
    mqtt_buff[all_size+1]=0x0A;
	mqtt_buff[all_size+2] = strlen(topic_name) /256;
	mqtt_buff[all_size+3] = strlen(topic_name) % 256;
    memcpy(&mqtt_buff[all_size+4], topic_name,strlen(topic_name)); 
	mqtt_buff[all_size+4+strlen(topic_name)]=QoS; 

	mqtt_DealTxData(mqtt_buff, all_size + variable_size + payload_size);  
	
}
void Mqtt_ConnectMessege()								//(connect����)ֻ��Ҫ��mqtt.h�иı��û����Ȳ��������Զ�װ��16�������ݣ����㶨ʣ�೤�ȵļ��㣬�����鷳
{
	int remaining_size;									//ʣ�೤��
	int len;
	int variable_size;  								//�ɱ䱨ͷ����                  					 
    int payload_size; 									//��Ч�غɳ��� 
	int all_size = 1;
	variable_size = 10;
	
    payload_size = 2 + clientid_size  + 2 + username_size  + 2 + passward_size;
	remaining_size = variable_size + payload_size;
	mqtt_buff[0] = 0x10;
	while( remaining_size > 0)
    {
        len= remaining_size%128;
		remaining_size = remaining_size/128;
         
         if(remaining_size > 0)
         {
              len =len|0x80;							//ת�����ƺ����λ��һ
         }
         mqtt_buff[all_size++]=len;
     }
	mqtt_buff[all_size+0]=0x00;							//�ɱ䱨ͷ    
    mqtt_buff[all_size+1]=0x04; 
    mqtt_buff[all_size+2]=0x4D;	
    mqtt_buff[all_size+3]=0x51;	
    mqtt_buff[all_size+4]=0x54;	
    mqtt_buff[all_size+5]=0x54;	
    mqtt_buff[all_size+6]=0x04;	
    mqtt_buff[all_size+7]=0xC2;	
    mqtt_buff[all_size+8]=0x00; 	
    mqtt_buff[all_size+9]=0x64;
	 
	mqtt_buff[all_size+10] = clientid_size /256;
	mqtt_buff[all_size+11] = clientid_size % 256;
    memcpy(&mqtt_buff[all_size+12], clientid, clientid_size);	//��ʶ��
	 
    mqtt_buff[all_size+12+ clientid_size] = username_size/256;	 
    mqtt_buff[all_size+13+ clientid_size] = username_size %256;
    memcpy(&mqtt_buff[all_size+14+ clientid_size], username, username_size);//�û���
	 
    mqtt_buff[all_size+14+clientid_size+username_size] = passward_size /256;	 
    mqtt_buff[all_size+15+clientid_size+username_size] = passward_size %256;
    memcpy(&mqtt_buff[all_size+16+clientid_size+username_size], passward, passward_size);//����
	mqtt_DealTxData (mqtt_buff, all_size + variable_size + payload_size);
}
void mqtt_PublishQs0(char *topic, char *data, int data_len)		//��������
{
	int all_size = 1;
	int variable_size,payload_size,remaining_size,len;
	variable_size = 2 + strlen(topic);
	payload_size = data_len;
	remaining_size = variable_size + payload_size;
	mqtt_buff[0] = 0x30;
	while( remaining_size > 0)
	{
		len= remaining_size%128;
		remaining_size = remaining_size/128;       
		 if(remaining_size > 0)
		 {
			  len =len|0x80;
		 }
		 mqtt_buff[all_size++]=len;
    }

	mqtt_buff[all_size+0]=strlen(topic)/256;                      
	mqtt_buff[all_size+1]=strlen(topic)%256;		               
	memcpy(&mqtt_buff[all_size+2],topic,strlen(topic));           	
	memcpy(&mqtt_buff[all_size+2+strlen(topic)],data,data_len); 
	mqtt_DealTxData(mqtt_buff, all_size + variable_size + payload_size);
}
void mqtt_DealCmdSet(unsigned char *data, int size)				//��������
{	
	memcpy(&mqtt_CMDInPtr[2],data,size);      		
	mqtt_CMDInPtr[0] = size/256;              
	mqtt_CMDInPtr[1] = size%256;              
	mqtt_CMDInPtr[size+2] = '\0';             
	mqtt_CMDInPtr+=400;                 
	if(mqtt_CMDInPtr==mqtt_CMDEndPtr)         
		mqtt_CMDInPtr = mqtt_CMDBuf[0];      
}
void mqtt_Dealsetdata_Qs0(unsigned char *redata)				//���������
{
	int i,topic_len,cmd_len,cmd_local,temp,temp_len,multiplier;
	unsigned char tempbuff[400];	   
	unsigned char *data;
	temp_len = 0;
	i=multiplier=1;	                              		
	data = &redata[2];			
	do{
		temp=data[i];
		temp_len+=(temp & 127) *multiplier;
		multiplier *= 128;
		i++;
	}while ((temp & 128) != 0);	
	topic_len = data[i]*256+data[i+1]+2;
	cmd_len = temp_len-topic_len;
	cmd_local= topic_len+i;
	memcpy(tempbuff,&data[cmd_local],cmd_len);
	mqtt_DealCmdSet(tempbuff, cmd_len); 
}

void mqtt_DealTxData (unsigned char *data, int size)			//�����͵������ȷ���mqtt_TxInPtr���������⴫��ʧ��
{
	mqtt_TxInPtr[0] = size/256; 
	mqtt_TxInPtr[1] = size%256; 
	memcpy(&mqtt_TxInPtr[2],data,size); 
	mqtt_TxInPtr+=400; 
	if(mqtt_TxInPtr==mqtt_TxEndPtr) 
	   mqtt_TxInPtr = mqtt_TxBuf[0];	
}

void mqtt_Ping(void)											//��������������������
{
	mqtt_buff[0]=0xC0;                                    
	mqtt_buff[1]=0x00;               

	mqtt_DealTxData(mqtt_buff, 2);   
}

void Ali_MsessageInit()											//������������Ϣ�Լ�connect����Ԥ������
{
    char temp[128];
	memset(clientid,128,0); 
	sprintf(clientid,"%s|securemode=3,signmethod=hmacsha1|",DEVICENAME); 
    clientid_size = strlen(clientid); 
	
	memset(username,128,0); 
	sprintf(username,"%s&%s",DEVICENAME,PRODUCTKEY); 
	username_size = strlen(username); 
	
	memset(temp,128,0); 
	sprintf(temp,"clientId%sdeviceName%sproductKey%s",DEVICENAME,DEVICENAME,PRODUCTKEY); 
	utils_hmac_sha1(temp,strlen(temp),passward,DEVICESECRE,DEVICESECRE_LEN);                 
    passward_size = strlen(passward);
	
	memset(ServerIP,128,0);  
	sprintf(ServerIP,"%s.iot-as-mqtt.cn-shanghai.aliyuncs.com",PRODUCTKEY);                  //��������������
	ServerPort = 1883; 
}
