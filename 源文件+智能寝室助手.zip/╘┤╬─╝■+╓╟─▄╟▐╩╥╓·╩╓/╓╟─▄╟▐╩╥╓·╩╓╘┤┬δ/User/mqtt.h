#ifndef __MQTT_H__
#define __MQTT_H__

#include "sys.h"

#define  DEVICENAME      "device1" 														
#define  PRODUCTKEY      "a1IczKxTUug"													
#define  DEVICESECRE     "a888bb4b73a2c9b680dd76efa9c8d500" 
#define  DEVICESECRE_LEN      strlen(DEVICESECRE)

#define  SUBSCRIBE_TOPIC1         "/sys/a1IczKxTUug/device1/thing/service/property/set"  //��������1
#define  PUBLISH_TOPIC1          "/sys/a1IczKxTUug/device1/thing/event/property/post"    //��������1    

#define  SUBSCRIBE_TOPIC2         "/ext/ntp/a1IczKxTUug/device1/response"  				//��������2
#define  PUBLISH_TOPIC2          "/ext/ntp/a1IczKxTUug/device1/request"    			    //��������2  


#define  mqtt_TxData(x)       u2_TxData(x) 

extern char ServerIP[128];                                  
extern int  ServerPort;

extern unsigned char  mqtt_TxBuf[10][400];           
extern unsigned char *mqtt_TxInPtr;                            
extern unsigned char *mqtt_TxOutPtr;                           
extern unsigned char *mqtt_TxEndPtr;

extern unsigned char  mqtt_RxBuf[10][400];           
extern unsigned char *mqtt_RxInPtr;                            
extern unsigned char *mqtt_RxOutPtr;                           
extern unsigned char *mqtt_RxEndPtr;

extern unsigned char  mqtt_CMDBuf[10][400];              
extern unsigned char *mqtt_CMDInPtr;                               
extern unsigned char *mqtt_CMDOutPtr;                              
extern unsigned char *mqtt_CMDEndPtr; 

extern u8 Connect_flag;
extern u8 ConnectPack_flag; 
extern u8 SubscribePack1_flag;
extern u8 SubscribePack2_flag;
extern u8 Ping_flag;
void Mqtt_ConnectMessege(void);
void Ali_MsessageInit(void);
void MQTT_Buff_Init(void);
void mqtt_Ping(void);
void mqtt_PublishQs0(char *topic, char *data, int data_len);
void mqtt_Dealsetdata_Qs0(unsigned char *redata);
#endif

